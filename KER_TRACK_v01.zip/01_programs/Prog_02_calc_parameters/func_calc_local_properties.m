function [RES_ALL] =func_calc_local_properties(TRACK,window_width, fpm)

unique_TRACK_IDs = unique(TRACK.TRACK_ID);
%%  loop tracks
for i=1:numel(unique_TRACK_IDs)
        %     get track
        TRACK = TRACK(TRACK.TRACK_ID == unique_TRACK_IDs(i),:);
        % create RES of TRACK table
        RES = array2table(NaN(size(TRACK,1), 2));
        RES.Properties.VariableNames = {  'move_mean_speed' 'move_mean_advance'  };
        % calculate
        move_mean_speed = func_calc_moving_mean_speed(TRACK, window_width, fpm);
        move_mean_advance = func_calc_moving_mean_advancement(TRACK, window_width, fpm);
        
         % into RES
        RES.move_mean_speed = move_mean_speed;
        RES.move_mean_advance = move_mean_advance;
        RES_ALL = [TRACK RES];

end