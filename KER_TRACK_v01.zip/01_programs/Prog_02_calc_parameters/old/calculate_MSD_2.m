function [Res_alpha] = calculate_MSD_2 (f,tracks, pos)

SPACE_UNITS = '�m';
TIME_UNITS = 's';
N_TIME_STEPS = 20;
dT = 1; % s,

ma = msdanalyzer(2, SPACE_UNITS, TIME_UNITS);
ma = ma.addAll(tracks);


%% plot 1
% f = subplot(4,5,pos*5+1);
% ma.plotTracks;
% ma.labelPlotTracks;
ma = ma.computeMSD;
ma.msd;

t = (0 : N_TIME_STEPS)' * dT;
[T1, T2] = meshgrid(t, t);
all_delays = unique( abs(T1 - T2) );
xlim([0 80])
ylim([0 80])
fprintf('Found %d different delays.\n', numel(all_delays));
% disp(all_delays(1:9));
fprintf('For %d time-points, found %d different delays.\n', N_TIME_STEPS, size( ma.msd{1}, 1 ) );

%% plot 2
f = subplot(4,5,pos*5+2);
ma.plotMSD;

%     xlim([0 80])
ylim([0 5])

% diff scale for tracks_y
  if pos == 2
      ylim([0 0.3])  
    end

%%                                                                   plot 3

f = subplot(4,5,pos*5+3);
cla
ma.plotMeanMSD(gca, true)
mmsd = ma.getMeanMSD;
t = mmsd(:,1);
x = mmsd(:,2);
dx = mmsd(:,3) ./ sqrt(mmsd(:,4));
errorbar(t, x, dx, 'k')

%% Fit of the linear part of the MSD.

% [fo, gof,D] = ma.fitMeanMSD( 0.5 );
% fo
% gof
% plot(fo)

results=ma.fitLogLogMSD(0.5);
Alphas=results.loglogfit.alpha;

% Res.D = D;
% Res.r2 = gof.adjrsquare;
% Res.p1 = fo.p1;
% Res.p2 = fo.p2;
Res_alpha.alphas = Alphas;



legend off
ma.labelPlotMSD
%       xlim([0 80])
    ylim([0 2])

% diff scale for tracks_y    
    if pos == 2
      ylim([0 0.3])  
    end

%% Velocity analysis.                                                plot 4
f = subplot(4,5,pos*5+4);
v = ma.getVelocities; %#ok<NOPTS>
V = vertcat( v{:} );
hist(V(:, 2:end), 50) % we don't want to include the time in the histogram
box off
xlabel([ 'Velocity (' SPACE_UNITS '/' TIME_UNITS ')' ])
ylabel('#')
        xlim([- 0.8 0.8])
    ylim([0 10])
%% Velocity autocorrelation.
f = subplot(4,5,pos*5+5);
ma = ma.computeVCorr;
ma.vcorr;
ma.plotMeanVCorr;
   xlim([ 0 30])
    ylim([-0.1 1])
end