
%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
curr_dir = pwd;

%%
%% data for transformation of "pixel per frame" to "�m per minute"

xy_scale = 0.0775225; % in �m per pixel
dt = 20; %recording interval in sec
t_scale = 60/dt; 
scale2um_min = xy_scale * t_scale;

scales.xy = xy_scale;
scales.t =  t_scale;

window_width = 8;  % 2,4,6,8,..
fpm = 3;   % frames per minute



%%


configfile = "l:\windoff\001 Projekte\0499 EBS Long Movies\02_programs\config.csv";
ConfigTable= importfile_configfile(configfile );
ConfigTable.Properties.VariableNames{1} = 'datadir';
ConfigTable.Properties.VariableNames{2} = 'active';
% set(0,'DefaultFigureVisible','off')
disp('_____________________________________________________________________');
%%

% %% get root dir
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;

cd (curr_dir);
%% loopthrough config MAIN LOOP
for counter01 = 1 : size (ConfigTable,1)
   if (ConfigTable.active(counter01) == 1)
       %% get files parameter etc
        %  load *_Spots in tracks statistics.csv
        filename_1 = ['long_', sprintf('%02.0f',counter01), '_Spots in tracks statistics.csv'];
        work_file = fullfile(ConfigTable.datadir{counter01}, filename_1);
        TABLE_SPOTS = readtable(work_file);
        cprintf([1,0,1],'working on %s\n', work_file );

        %  load *_ex001_Links in tracks statistics.csv
        filename_2 = ['long_', sprintf('%02.0f',counter01), '_Links in tracks statistics.csv'];
        work_file_2 = fullfile(ConfigTable.datadir{counter01}, filename_2);
        TABLE_LINKS = readtable(work_file_2);

        % get last track
        last_track = max(TABLE_SPOTS.TRACK_ID);
        counter03 = 1;
        % assignoutdir
        outdirs = ConfigTable.datadir{counter01};
        ex_name = strsplit(filename_1,'_');
        ex_name = ['long_', ex_name{2}];
        
        cd (outdirs);
%         dir_name = [out_ex_name 'out_01'];
        mkdir ('out_01');
        mkdir ('out_02');
        cd (curr_dir);

    %% #####################################  loop through Tracks
    
    %% ++++++++++++++++++++++++++calculate subtracks and parameter   START
   for counter02 = 0 : last_track                                               % PARFOR SWITCH
%     for counter02 = 0 : 15   % or last_track
     

                if ismember(counter02,TABLE_SPOTS.TRACK_ID) == 1    
                            TRACK_spots = TABLE_SPOTS(TABLE_SPOTS.TRACK_ID == counter02 , :);
                            TRACK_links = TABLE_LINKS(TABLE_LINKS.TRACK_ID == counter02 , :);
                            A_nodes = func_find_nodes(TRACK_links.SPOT_SOURCE_ID, TRACK_links.SPOT_TARGET_ID);    
                            merges = size (A_nodes,1);
                            res = func_get_subtracks(TRACK_spots,TRACK_links, ex_name, counter02 , merges,scales,  outdirs);     
               end % if
    end
    % .............................calculate subtracks and parameter   END
    
    %%  +++++++++++++++++++++++++++++++++++++++++++++++++merge files  START
    dir_name = [outdirs, 'out_02'];
    file_out =  [dir_name '\' ex_name '_all_frames_tracks_subtracks.csv'];



    load_files = dir(fullfile(dir_name, '*all_track_parameters2.csv'));
    nfiles = length(load_files);
    T= readtable(fullfile(dir_name, load_files(1).name));
    cprintf([1,0.5,0],'reading and combining files...be patient.~5 min..  \n');
    for counter = 2 : nfiles
            T_new= readtable(fullfile(dir_name, load_files(counter).name));
            T = [T; T_new];
    end 
    writetable(T,file_out);
    cprintf([1,1,1],'saved:  %s    \n', file_out);
    %  ................................................merge files     END
    
    %% +++++++++++++++++++++++++++++++++++++++++++++++FILTER TRACKS - START
    
    filter_first = 0;
    filter_last = 199;
    filter_size = 9;


    file_in = file_out;
    T= readtable(file_in);

    co_filtered_main = 0;
    co_filtered_solo = 0;

    %% create result table from scratch
    T_SOLOTRACKS = array2table(NaN(0,31));
    T_SOLOTRACKS.Properties.VariableNames = ...   
                    {'Label'... 
                    'ID'... 
                    'TRACK_ID'... 
                    'QUALITY'... 
                    'POSITION_X'... 
                    'POSITION_Y'... 
                    'POSITION_Z'... 
                    'POSITION_T'... 
                    'FRAME'... 
                    'RADIUS'... 
                    'VISIBILITY'... 
                    'MANUAL_COLOR'... 
                    'MEAN_INTENSITY'... 
                    'MEDIAN_INTENSITY'... 
                    'MIN_INTENSITY'... 
                    'MAX_INTENSITY'... 
                    'TOTAL_INTENSITY'... 
                    'STANDARD_DEVIATION'... 
                    'ESTIMATED_DIAMETER'... 
                    'CONTRAST'... 
                    'SNR'... 
                    'spot_type'... 
                    'SUBTRACK'... 
                    'step_size'... 
                    'track_length'... 
                    'flag'... 
                    'speed_track'... 
                    'dist_total'... 
                    'speed_dist'... 
                    'angle_2first'... 
                    'num_merges'};
            %%  main FILETER LOOP
            T_MAINTRACKS = T_SOLOTRACKS;

            unique_TRACK_IDs = unique(T.TRACK_ID);
            cprintf([1,0.5,0],'wip: filtering tracks....  \n');
            for i=1:numel(unique_TRACK_IDs)
                T_track = T(T.TRACK_ID == unique_TRACK_IDs(i),:); 
            %     cprintf([1,0.5,0],'working on %6.0f \n', unique_TRACK_IDs(i));
                T_track = T_track(T_track.SUBTRACK == 1,:);
            %     cprintf([1,0.5,0],'Main or solo Track on %6.0f \n', unique_TRACK_IDs(i));

            %%         ------------------------------------------------------SOLO TRACKS
                  if T_track.num_merges(1) == 0    %  SOLO track
            %             cprintf([1,0,0],'solo Track on %6.0f \n', unique_TRACK_IDs(i));
                        if T_track.FRAME(1) > filter_first     % start after first fram
                            if T_track.FRAME(end) < filter_last  % end before last frame
                                if size(T_track, 1) > filter_size  % more then 9 frames 
                                    co_filtered_solo = co_filtered_solo +1;
            %                          cprintf([1,0,1],'filtered solo Track on %6.0f   %6.0f\n', unique_TRACK_IDs(i), co_filtered_solo);
                                     T_SOLOTRACKS = [T_SOLOTRACKS; T_track];
                                end
                            end
                        end
             %%         ------------------------------------------------------MAIN TRACKS  
                  elseif T_track.num_merges(1) > 0 %  MAIN track
            %       else
            %              cprintf([1,1,0],'MAIN Track on %6.0f \n', unique_TRACK_IDs(i));
                         if T_track.FRAME(1) > filter_first     % start after first fram
                            if T_track.FRAME(end) < filter_last  % end before last frame
                                if size(T_track, 1) > filter_size  % more then 9 frames 
                                    co_filtered_main = co_filtered_main +1;
            %                          cprintf([1,1,1],'filtered MAIN Track on %6.0f   %6.0f \n', unique_TRACK_IDs(i), co_filtered_main);
                                    T_MAINTRACKS = [T_MAINTRACKS; T_track];
                                end
                            end
                         end
                  end
                deb =0;
            end
            cprintf([0,1,0],'filter settings: \nfilter_first=%4.0f \nfilter_last= %4.0f  \nfilter_size= %4.0f \n' ...
                , filter_first, filter_last, filter_size);
            cprintf([1,1,1],'filtered MAIN Tracks %6.0f    \n', co_filtered_main);
            cprintf([1,1,1],'filtered SOLO Tracks %6.0f    \n', co_filtered_solo);


            %% saving

            file_out_SOLO =  [dir_name '\' ex_name  '_all_frames_tracks_subtracks_filtered_SOLO.csv'];
             writetable(T_SOLOTRACKS,file_out_SOLO);

             cprintf([1,1,1],'saved:  %s    \n', file_out_SOLO);
             file_out_MAIN =  [dir_name '\' ex_name  '_all_frames_tracks_subtracks_filtered_MAIN.csv'];
             writetable(T_MAINTRACKS,file_out_MAIN);
            cprintf([1,1,1],'saved:  %s    \n', file_out_MAIN);
    
    %% ................................................FILTER TRACKS - END
    
    %% ++++++++++++++++++++++++++++++++++++++++++++ calc local speed - START
    M = readtable(file_out_SOLO);
    [RES_ALL] =func_calc_local_properties_v02(M,window_width, fpm);
    file_out_local_SOLO = [dir_name '\' ex_name  '_SOLO_tracks_mms_mma_bright_w_8.csv'];
    writetable(RES_ALL,file_out_local_SOLO,'Delimiter','\t');
    
    M = readtable(file_out_MAIN);
    [RES_ALL] =func_calc_local_properties_v02(M,window_width, fpm);
    file_out_local_MAIN = [dir_name '\' ex_name  '_MAIN_tracks_mms_mma_bright_w_8.csv'];
    writetable(RES_ALL,file_out_local_MAIN,'Delimiter','\t');
    
    deb = 0;
    
     %% ..............................................calc local speed - END
    
%    close(h); 
     debug =0;
    
       deb =0;
       
       
    end
end


 debug =0;

%% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
disp('__________________________________________________');