
%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
curr_dir = pwd;

 tracktype = 'MAINTRACKS';
%  tracktype = 'SOLOTRACKS';


%%
out_dir = 'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\';
mkdir (out_dir);

configfile = 'l:\windoff\001 Projekte\0498 wip papersj\Analysis\00_ program\Prog_13_calc_localMSD\config_MSD.csv';
ConfigTable= importfile_configfile(configfile );
ConfigTable.Properties.VariableNames{1} = 'datadir';
ConfigTable.Properties.VariableNames{2} = 'active';
% set(0,'DefaultFigureVisible','off')
disp('_____________________________________________________________________');
%%

% %% get root dir
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;

%% ------------------------------------------create empty table for results
RESULT = cell2table(cell(0,7));
RESULT.Properties.VariableNames = ...
    {'ID' 'MSD_D' 'MSD_r2' 'MSD_p1'...
    'MSD_p2' 'MSD_alpha' 'var1'};

cd (curr_dir);
%% loopthrough config MAIN LOOP
counter02 =1;
for counter01 = 1 : size (ConfigTable,1)
    if (ConfigTable.active(counter01) == 1)

        if (tracktype == 'MAINTRACKS')   
        filename_1 = ['out_02\long_', sprintf('%02.0f',counter01),  'all_frames_tracks_subtracks_filtered_MAIN.csv'];
        file_2_read ='l:\windoff\001 Projekte\0498 wip papersj\Analysis\03_out_all_subtracks_ABCD\A\all_frames_tracks_subtracks_filtered_MAIN.csv';

        elseif (tracktype == 'SOLOTRACKS')
        file_2_read ='l:\windoff\001 Projekte\0498 wip papersj\Analysis\03_out_all_subtracks_ABCD\A\all_frames_tracks_subtracks_filtered_SOLO.csv';
        end


        %         work_file = fullfile(ConfigTable.datadir{counter01}, filename_1);
        cprintf([1,0,1],'working on %s\n', file_2_read );
        ALL_TRACKS = readtable(file_2_read);
        unique_TRACK_IDs = unique(ALL_TRACKS.TRACK_ID);
        size_= size(unique_TRACK_IDs,1);

        %% ###################################################LOOP TRACKS START
                     
%         for co_01=1:numel(unique_TRACK_IDs)
            for co_01=1:5
            
            TRACK = ALL_TRACKS(ALL_TRACKS.TRACK_ID == unique_TRACK_IDs(co_01),:);
            last_time = height(TRACK);
            cprintf([1,0,1],'working on %f\n', co_01 );
            
            %% rotate
            debug = 0;
            x0 = TRACK.POSITION_X(1);
            y0 = TRACK.POSITION_Y(1);
            theta = TRACK.angle_2first(height(TRACK));
            R = [cosd(theta) -sind(theta); sind(theta) cosd(theta)];

            for cc = 1:height(TRACK)
            v = [TRACK.POSITION_X(cc)-x0 TRACK.POSITION_Y(cc)-y0];
            vR = v*R;
            rot(cc,:) =vR;
            end
            debug = 0;
            %% end rotation  
            
             %% transform data into target format for MSD    
            tr_xy(1:last_time,2) = TRACK.POSITION_X(1:last_time,1);
            tr_xy(1:last_time,3) = TRACK.POSITION_Y(1:last_time,1);
            tr_xy(1:last_time,1) = [1:size(tr_xy,1)]' * 1;            
            tr_x(1:last_time,2) = rot(1:last_time,1);
            tr_x(1:last_time,3) =  0;
            tr_x(1:last_time,1) = [1:size(tr_xy,1)]' * 1;
            tr_y(1:last_time,2) =  0;
            tr_y(1:last_time,3) = rot(1:last_time,2);
            tr_y(1:last_time,1) = [1:size(tr_xy,1)]' * 1;
            
%             tr_xy = tr_xy(1:10,:,1); % TEST ONLY points 1 to 10
                % last points
%             ee = size(tr_xy,1) -8;
%             tr_xy = tr_xy(ee:end,:,1);
              % first points
             tr_xy = tr_xy(1:8,:,1);
            
            tracks_xy{1,1} = tr_xy;
            tracks_x{1,1} = tr_x;
            tracks_y{1,1} = tr_y;
            clearvars tr_xy tr_x tr_y
            %% transform data into target format for MSD
            %% ................................calculate MSD of xy__START
            position = 1;
            f = figure('Position',[100,100,1800,1200],'visible','on');
            Res = calculate_MSD_2 (f, tracks_xy, position);
%             RESULT(counter01-2).xy_D = Res.D;
%             RESULT(counter01-2).xy_r2 = Res.r2;
%             RESULT(counter01-2).xy_p1 =Res.p1;
%             RESULT(counter01-2).xy_p2 = Res.p2;
            %         RESULT(counter01-2).xy_alpha = Res.alphas;
%             RESULT(counter01-2).xy_mean_alpha = mean(Res.alphas);
            %%
            %         STAT(1,:).alpha_xy = Res.alphas
            %              STAT(co03,:).alpha_xy = RESULT(1:length(RESULT)).xy_mean_alpha
%             for co03 = 1:length(STAT)
%             STAT(co03,:).alpha_xy =  Res(1,1).alphas(co03,:);
%             end    
            clearvars Res
            %% ................................calculate MSD of xy__END
            filename_ = [out_dir num2str(co_01) '_out.tif']
            saveas(f,filename_);
            close all;
            deb =0;

        end


%         res = func_stats_lifetime_v02 (TABLES, tracktype, out_dir, counter01);




        debug =0;
    end
end


 debug =0;
 filename = [out_dir, '\', tracktype, '_Stats01.csv'];
 writetable(RESULT,filename,'Delimiter',',');
 close all

%% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
disp('__________________________________________________');        