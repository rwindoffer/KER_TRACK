
%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
curr_dir = pwd;
windowsize =8; 
% don't change, in  ALL_TRACKS.alpha_xy(ix(1)+3:ix(end)-4) = struct2array(TRACK_MSD)';
% not integrated


tracktype = 'MAINTRACKS';
tracktype = 'SOLOTRACKS';


%%
out_dir = 'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\';
mkdir (out_dir);

configfile = 'l:\windoff\001 Projekte\0498 wip papersj\Analysis\00_ program\Prog_13_calc_localMSD\config_MSD.csv';
ConfigTable= importfile_configfile(configfile );
ConfigTable.Properties.VariableNames{1} = 'datadir';
ConfigTable.Properties.VariableNames{2} = 'active';
% set(0,'DefaultFigureVisible','off')
disp('_____________________________________________________________________');
%%

% %% get root dir
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;

%% ------------------------------------------create empty table for results
RESULT = cell2table(cell(0,7));
RESULT.Properties.VariableNames = ...
    {'ID' 'MSD_D' 'MSD_r2' 'MSD_p1'...
    'MSD_p2' 'MSD_alpha' 'var1'};

cd (curr_dir);
%% loopthrough config MAIN LOOP
counter02 =1;
for counter01 = 1 : size (ConfigTable,1)
    if (ConfigTable.active(counter01) == 1)

        if (tracktype == 'MAINTRACKS')   
        filename_1 = ['out_02\long_', sprintf('%02.0f',counter01),  'all_frames_tracks_subtracks_filtered_MAIN.csv'];
        file_2_read ='l:\windoff\001 Projekte\0498 wip papersj\Analysis\03_out_all_subtracks_ABCD\A\all_frames_tracks_subtracks_filtered_MAIN.csv';

        elseif (tracktype == 'SOLOTRACKS')
        file_2_read ='l:\windoff\001 Projekte\0498 wip papersj\Analysis\03_out_all_subtracks_ABCD\A\all_frames_tracks_subtracks_filtered_SOLO.csv';
        end
       
        % load workfile 

        %         work_file = fullfile(ConfigTable.datadir{counter01}, filename_1);
        cprintf([1,0,1],'working on %s\n', file_2_read );
        ALL_TRACKS = readtable(file_2_read);
        tsize = size(ALL_TRACKS,1);
        unique_TRACK_IDs = unique(ALL_TRACKS.TRACK_ID);
        size_= size(unique_TRACK_IDs,1);
        
         % add colum for MSD-alpha
        T_new = array2table(NaN(tsize,3));
        T_new.Properties.VariableNames = {'alpha_xy', 'alpha_x','alpha_y'};
        ALL_TRACKS = [ALL_TRACKS, T_new];
         

        %% ###################################################LOOP TRACKS START
                     
       for co_01=1:numel(unique_TRACK_IDs)
%              for co_01=1:5
            
            TRACK = ALL_TRACKS(ALL_TRACKS.TRACK_ID == unique_TRACK_IDs(co_01),:);
           
            
            [TRACK_MSD_xy, TRACK_MSD_x, TRACK_MSD_y] = func_calc_moving_MSD_v01(TRACK, windowsize);
            
            
            close all
            
            % into ALL_TRACKS
            ix = find(ALL_TRACKS.TRACK_ID == unique_TRACK_IDs(co_01));
            ALL_TRACKS.alpha_xy(ix(1)+3:ix(end)-4) = struct2array(TRACK_MSD_xy)';
            ALL_TRACKS.alpha_x(ix(1)+3:ix(end)-4) = struct2array(TRACK_MSD_x)';
            ALL_TRACKS.alpha_y(ix(1)+3:ix(end)-4) = struct2array(TRACK_MSD_y)';
            
            
            
            
            debug = 0;
%             filename_ = [out_dir num2str(co_01) '_out.tif']
%             saveas(f,filename_);
%             close all;
%             deb =0;

        end


%         res = func_stats_lifetime_v02 (TABLES, tracktype, out_dir, counter01);




        debug =0;
    end
end


 debug =0;
 filename = [out_dir, '\', tracktype, '_Stats01.csv'];
 writetable(ALL_TRACKS,filename,'Delimiter',',');
 close all

%% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
disp('__________________________________________________');        