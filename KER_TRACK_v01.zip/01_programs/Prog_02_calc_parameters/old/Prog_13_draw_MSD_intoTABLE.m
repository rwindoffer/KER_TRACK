% shrinkage or growth
% xyf
% f=1 SOLO or main 
% f=2 SOLO or main 
% f=3 subtrack
% f=4 subtrack


%% ............................................................. INITIALIZE
startup

%% ...............................................................parameter
filename = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\MAINTRACKS_Stats01.csv';

filename = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\SOLOTRACKS_Stats01.csv';
file2write = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\xy_MSD.csv';

%% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!from all tracks birth = M.spot_type == 1




cprintf([1,0.5,0],'working on %s\n', filename);
M = readtable(filename);
unique_TRACK_IDs = unique(M.TRACK_ID);
size_= size(unique_TRACK_IDs,1);
RES_ALL = NaN(size_,4);
%f = figure('Position',[120,120,1200,1200]);



%% !!!!!!!!!!!!!!!!!!!!!!!!from SOLO and MAIIN death = last in track


%             T_track = T_track(T_track.SUBTRACK == 1,:);
%             if T_track.num_merges(1) == 0    %  SOLO track
%             elseif T_track.num_merges(1) > 0 %  MAIN track

    
% SOLOuMAIN_tracks = M(M.SUBTRACK == 1,:);   
    
unique_TRACK_IDs = unique(M.TRACK_ID);
size_= size(unique_TRACK_IDs,1);
RES_ALL = NaN(size_,3);

% set(gcf,'color','w');
co_03 =1;
%%  loop tracks
cprintf([1,0.5,0],'working on  ....\n' );
%%  loop tracks 'qu u dirt', 2 sec
for i=1:numel(unique_TRACK_IDs)
        %     get track
                TRACK = M(M.TRACK_ID == unique_TRACK_IDs(i),:);
         size_T = height(TRACK);
for co_02 = 4 : size_T -5
                     RES_ALL(co_03,1) = TRACK.POSITION_X(co_02);
                    RES_ALL(co_03,2) = TRACK.POSITION_Y(co_02);

                    RES_ALL(co_03,3) = TRACK.alpha_xy(co_02);
                    co_03 = co_03 +1;
           
            
    end          
deb =0;
        
end   
file2write = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\xy_MSD.csv';
writematrix(RES_ALL,file2write,'Delimiter','tab' );

for i=1:numel(unique_TRACK_IDs)
        %     get track
                TRACK = M(M.TRACK_ID == unique_TRACK_IDs(i),:);
         size_T = height(TRACK);
for co_02 = 4 : size_T -5
                     RES_ALL(co_03,1) = TRACK.POSITION_X(co_02);
                    RES_ALL(co_03,2) = TRACK.POSITION_Y(co_02);

                    RES_ALL(co_03,3) = TRACK.alpha_x(co_02);
                    co_03 = co_03 +1;
           
            
    end          
deb =0;
        
end   
file2write = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\x_MSD.csv';
writematrix(RES_ALL,file2write,'Delimiter','tab' );



for i=1:numel(unique_TRACK_IDs)
        %     get track
                TRACK = M(M.TRACK_ID == unique_TRACK_IDs(i),:);
         size_T = height(TRACK);
for co_02 = 4 : size_T -5
                     RES_ALL(co_03,1) = TRACK.POSITION_X(co_02);
                    RES_ALL(co_03,2) = TRACK.POSITION_Y(co_02);

                    RES_ALL(co_03,3) = TRACK.alpha_y(co_02);
                    co_03 = co_03 +1;
           
            
    end          
deb =0;
        
end   
file2write = ...
'l:\windoff\001 Projekte\0498 wip papersj\Analysis\11_out_MSD\y_MSD.csv';
writematrix(RES_ALL,file2write,'Delimiter','tab' );
%% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
