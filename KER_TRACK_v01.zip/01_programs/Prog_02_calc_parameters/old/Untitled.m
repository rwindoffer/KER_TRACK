%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
warning off MATLAB:MKDIR:DirectoryExists
curr_dir = pwd;
disp('_____________________________________________________________________');
%% assign directories
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;

%% assign save directory
%  outdirs{1}=  [dir_name, '\\02_out_trees\\'];
out_dir =  [dir_name, '\\03_out_all_subtracks_MSD\\'];
cd (curr_dir); % back to working dir

%% load list of files to be processed = load_files 2x
dir_name_load = [dir_name, '\\02_out_all_subtracks\\'];
load_files = dir(fullfile(dir_name_load, '*_all_track_parameters2.csv'));
nfiles = length(load_files);

%% set var
windowsize =8; 
%% ##################################loop through experiments
for counter01 = 1 : nfiles    % 

    work_file = fullfile(dir_name_load, load_files(counter01).name);
    TRACK = readtable(work_file);  
% 
% file_2_read = 'l:\windoff\001 Projekte\0531 M-track_in2_pub\root\02_out_all_subtracks\track_0000_subtrack_001_all_track_parameters2.csv';
% TRACK = readtable(file_2_read);

tsize = size(TRACK,1);
T_new = array2table(NaN(tsize,3));
        T_new.Properties.VariableNames = {'alpha_xy', 'alpha_x','alpha_y'};
        TRACK = [TRACK, T_new];



 [TRACK_MSD_xy, TRACK_MSD_x, TRACK_MSD_y] = func_calc_moving_MSD_v01(TRACK, windowsize);
 
  TRACK.alpha_xy(4:end-4) = struct2array(TRACK_MSD_xy)';
            TRACK.alpha_x(4:end-4) = struct2array(TRACK_MSD_x)';
            TRACK.alpha_y(4:end-4) =  struct2array(TRACK_MSD_y)';
   
            
            filename_new = strrep(load_files(counter01).name,'2','3');
            filename_2_save = [out_dir, '\', filename_new];
%              filename = [out_dir, '\', tracktype, '_Stats01.csv'];
             
             
 writetable(TRACK,filename_2_save,'Delimiter',',');
            
debug =0;            
end
            
            
            
            