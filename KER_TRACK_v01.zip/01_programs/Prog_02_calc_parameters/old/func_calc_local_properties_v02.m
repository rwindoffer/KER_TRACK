function [RES_ALL] =func_calc_local_properties_v02(M,window_width, fpm)

RES_ALL = array2table(NaN(0, 8));
RES_ALL.Properties.VariableNames = {'POSITION_X' 'POSITION_Y' 'move_mean_speed' 'move_mean_advance' 'MEAN_INTENSITY' 'merges' 'TRACK_ID' 'FRAME' };

unique_TRACK_IDs = unique(M.TRACK_ID);
%%  loop tracks
for i=1:numel(unique_TRACK_IDs)
        %     get track
        TRACK = M(M.TRACK_ID == unique_TRACK_IDs(i),:);
        % create RES of TRACK table
        RES = array2table(NaN(size(TRACK,1), 8));
        RES.Properties.VariableNames = {'POSITION_X' 'POSITION_Y' 'move_mean_speed' 'move_mean_advance' 'MEAN_INTENSITY' 'merges' 'TRACK_ID' 'FRAME' };
        % calc
        move_mean_speed = func_calc_moving_mean_speed(TRACK, window_width, fpm);
        move_mean_advance = func_calc_moving_mean_advancement(TRACK, window_width, fpm);
        
        % into RES
        RES.POSITION_Y = TRACK.POSITION_Y;
        RES.POSITION_X = TRACK.POSITION_X;
        RES.move_mean_speed = move_mean_speed;
        RES.move_mean_advance = move_mean_advance;
        RES.MEAN_INTENSITY = TRACK.MEAN_INTENSITY;
        RES.merges = TRACK.num_merges;
        RES.TRACK_ID = TRACK.TRACK_ID;
        RES.FRAME = TRACK.FRAME;
        RES_ALL = [RES_ALL; RES];
        
        deb =0;
    
    
end