function [res] = func_calc_moving_mean_advancement(TRACK, windows_steps_all, fpm)

% remember the shifted index of steps
% steps are indexed backwards
% e.g. windows_steps_all = 4 , is 1 back and 2 forward
% gives -1, 0, +1, +2

windows_steps = windows_steps_all/2;
move_mean_advance = nan((size(TRACK,1)),1);
for point_index_counter = 1 + windows_steps  : size(TRACK,1)- windows_steps
        i_first = point_index_counter - windows_steps;
        i_last = point_index_counter + windows_steps;
        % calculate advance for point_index_counter
        x1 = TRACK.POSITION_X(i_first);
        x2 = TRACK.POSITION_X(i_last);
        y1 = TRACK.POSITION_Y(i_first);
        y2 = TRACK.POSITION_Y(i_last);
        step_ = sqrt((x1-x2)^2+(y1-y2)^2);
        advance = step_/ windows_steps_all * fpm; 
        move_mean_advance(point_index_counter,1) = advance;
end
res = move_mean_advance;