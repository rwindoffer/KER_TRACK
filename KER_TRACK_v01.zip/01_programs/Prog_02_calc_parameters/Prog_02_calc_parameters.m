%% Prog_02_calc_parameters.m
% additional analysis of fiji/trackmate results

% alpha_xy	local (8 frames) MSD coefficient alpha, within moving window
% alpha_x	local (8 frames) MSD coefficient alpha, only x compound, within moving window
% alpha_y	local (8 frames) MSD coefficient alpha, only y compound, within moving window
% move_mean_speed	local (8 frames) speed
% move_mean_advance	local (8 frames) speed_dist



%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
warning off MATLAB:MKDIR:DirectoryExists
curr_dir = pwd;
disp('_____________________________________________________________________');
%% assign directories
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;



%% load list of files to be processed = load_files 2x
dir_name_load = [dir_name, '\\02_RESULT_all_subtracks\\'];
load_files = dir(fullfile(dir_name_load, '*.csv'));
nfiles = length(load_files);

%% assign output directory
out_dir =  [dir_name, '\\03_RESULT_all_subtracks_parameters\\'];
cd (curr_dir); % back to working dir

%% ...............................................................parameter
window_width = 8;  % 2,4,6,8,..
dt = {inputdlg('Please enter the recording interval? [seconds] ','Input')};
fpm =  60/str2double(dt{1,1}); 



%% ##################################loop through experiments
for counter01 = 1 : nfiles    % 

    
        fprintf('\n\n working on file  %d of %d\n\n',counter01, nfiles);
        work_file = fullfile(dir_name_load, load_files(counter01).name);
        TRACK = readtable(work_file);  
        tsize = size(TRACK,1);
        T_new = array2table(NaN(tsize,3));
        T_new.Properties.VariableNames = {'alpha_xy', 'alpha_x','alpha_y'};
        TRACK = [TRACK, T_new];
        %% calculate MSD
        if tsize>7
                [TRACK_MSD_xy, TRACK_MSD_x, TRACK_MSD_y] = func_calc_moving_MSD_v01(TRACK);
                TRACK.alpha_xy(4:end-4) = struct2array(TRACK_MSD_xy)';
                TRACK.alpha_x(4:end-4) = struct2array(TRACK_MSD_x)';
                TRACK.alpha_y(4:end-4) =  struct2array(TRACK_MSD_y)';
        end  
        
        %% calculate moving speed, moving advance
        [RES_ALL] =func_calc_local_properties(TRACK,window_width, fpm);
        
        filename_new = strrep(load_files(counter01).name,'.csv','_all.csv');
        filename_2_save = [out_dir, '\', filename_new];
        writetable(RES_ALL,filename_2_save,'Delimiter',',');

        debug =0;            
        end
            
            %% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
            
            