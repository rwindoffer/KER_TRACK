function [Res_alpha_xy,Res_alpha_x,Res_alpha_y] = func_calc_moving_MSD_v01 (whole_TRACK)

% steps are indexed backwards
% e.g. windows_steps_all = 4 , is 1 back and 2 forward
% gives -1, 0, +1, +2
windows_steps_all = 8; 
windows_steps_back = -(windows_steps_all/2-1);
windows_steps_forw = windows_steps_all/2;

for point_index_counter =  windows_steps_forw  : size(whole_TRACK,1)- windows_steps_forw
     fprintf('point_index_counter = %4.0f, ', point_index_counter);

            
            TRACK_WINDOW = (whole_TRACK (point_index_counter + windows_steps_back: point_index_counter + windows_steps_forw ,:));
            last_time = height(TRACK_WINDOW);

            
            %% rotate
            debug = 0;
            x0 = TRACK_WINDOW.POSITION_X(1);
            y0 = TRACK_WINDOW.POSITION_Y(1);
            theta = TRACK_WINDOW.angle_2first(height(TRACK_WINDOW));
            R = [cosd(theta) -sind(theta); sind(theta) cosd(theta)];

            for cc = 1:height(TRACK_WINDOW)
            v = [TRACK_WINDOW.POSITION_X(cc)-x0 TRACK_WINDOW.POSITION_Y(cc)-y0];
            vR = v*R;
            rot(cc,:) =vR;
            end
            debug = 0;
            %% end rotation  
            
             %% transform data into target format for MSD    
            tr_xy(1:last_time,2) = TRACK_WINDOW.POSITION_X(1:last_time,1);
            tr_xy(1:last_time,3) = TRACK_WINDOW.POSITION_Y(1:last_time,1);
            tr_xy(1:last_time,1) = [1:size(tr_xy,1)]' * 1;            
            tr_x(1:last_time,2) = rot(1:last_time,1);
            tr_x(1:last_time,3) =  0;
            tr_x(1:last_time,1) = [1:size(tr_xy,1)]' * 1;
            tr_y(1:last_time,2) =  0;
            tr_y(1:last_time,3) = rot(1:last_time,2);
            tr_y(1:last_time,1) = [1:size(tr_xy,1)]' * 1;
            

             tr_xy = tr_xy(1:8,:,1);
            
            tracks_xy{1,1} = tr_xy;
            tracks_x{1,1} = tr_x;
            tracks_y{1,1} = tr_y;
            clearvars tr_xy tr_x tr_y
            
            %% calc MSD
            Res_alpha_xy(point_index_counter) = calculate_MSD_alpha ( tracks_xy);
            Res_alpha_x(point_index_counter) = calculate_MSD_alpha ( tracks_x);
            Res_alpha_y(point_index_counter) = calculate_MSD_alpha ( tracks_y);
            deb =0;


end


res_xy = Res_alpha_xy;