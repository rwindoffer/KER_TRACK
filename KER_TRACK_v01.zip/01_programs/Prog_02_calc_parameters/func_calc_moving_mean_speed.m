function [res] = func_calc_moving_mean_speed (TRACK, windows_steps_all, fpm)

% steps are indexed backwards
% e.g. windows_steps_all = 4 , is 1 back and 2 forward
% gives -1, 0, +1, +2

windows_steps_back = -(windows_steps_all/2-1);
windows_steps_forw = windows_steps_all/2;
move_mean_speed = nan((size(TRACK,1)),1);

for point_index_counter = 1 + windows_steps_forw  : size(TRACK,1)- windows_steps_forw
    move_mean_speed(point_index_counter) = (sum(TRACK.step_size(point_index_counter + windows_steps_back: point_index_counter + windows_steps_forw))/windows_steps_all* fpm);
end
res = move_mean_speed;