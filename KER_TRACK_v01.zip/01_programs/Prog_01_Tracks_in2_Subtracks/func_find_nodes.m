function [merger] = func_find_nodes (SPOT_SOURCE_ID, SPOT_SOURCE_TARGET_ID)

last_= size(SPOT_SOURCE_TARGET_ID,1);
Res = zeros(last_, 2);
Res(:,1) = SPOT_SOURCE_ID;
Res(:,2) = SPOT_SOURCE_TARGET_ID;

T = array2table(Res);

[~,idxu,idxc] = unique(T.Res2);
% count unique values 
[count, ~, idxcount] = histcounts(idxc,numel(idxu));
%  more than one occurence
idxkeep = count(idxcount)>1;
% Extract from C
merger = T.Res2(idxkeep,:);

merger = unique(merger);

   
