function [res] = func_get_subtracks(TRACK_spots,TRACK_links , counter02, merges, scales, outdir)

warning('off','all')  
%% add empty column for tracked-flag
empty  = array2table(zeros(size(TRACK_links,1),1));
TRACK_links = [TRACK_links, empty];   
TRACK_links.Properties.VariableNames{'Var1'} = 'flag';

track = true;

counter_subtrack = 1;
%% --------------------------------------------------------loop through track 
while track    
        %%          define B (first untracked SPOT_TARGET_ID), = first flag == 0
        [first_spot_to_track, idx_1] = func_find_first(TRACK_links); % get first spot to be tracked, its index

        if isempty(idx_1) == 1
                res = 1;
                break
        end

        TRACK_links.flag(idx_1) = 1;   % flag as init (=1)
        spot_B = first_spot_to_track.SPOT_TARGET_ID;   
        subtrack = true;
        co_spot_in_subtrack = 1;
        subtrack_co = 1;
        T_subtrack = array2table(NaN(0,6));
        T_subtrack.Properties.VariableNames = {'idx' 'spot_A' 'spot_B' 'spot_index' 'flag1' 'flag2'};
        spot_A= TRACK_links.SPOT_SOURCE_ID(idx_1);  
        spot_B= TRACK_links.SPOT_TARGET_ID(idx_1);
        T_subtrack.idx(subtrack_co) = idx_1;   
        T_subtrack.spot_A(subtrack_co) = spot_A;
        T_subtrack.spot_B(subtrack_co) = spot_B;
        T_subtrack.flag1(subtrack_co) = spot_A;     
        T_subtrack.flag2(subtrack_co) = 1;
        subtrack_co = subtrack_co + 1;
        T_subtrack.flag1(subtrack_co) = spot_B;      
        T_subtrack.flag2(subtrack_co) = 2;
        subtrack_co = subtrack_co + 1;


        while subtrack   % loop through subtrack
                idx = find(TRACK_links.SPOT_SOURCE_ID==spot_B);% find index of first or next
                %% ------------------------------------------------------------------assign INIT
                if isempty(idx)   % if not found, exit subtrack
                    subtrack =    false;
                else
                    
                    if TRACK_links.flag(idx) == 2   % approaching merge
                        TRACK_links.flag(idx) = 3;     % set flag to 'merge'
                        T_subtrack.flag2(subtrack_co-1) = 4;
                        break
                    end        
                %% ------------------------------------------------------------------get linked spots
                spot_A= TRACK_links.SPOT_SOURCE_ID(idx);  
                spot_B= TRACK_links.SPOT_TARGET_ID(idx);
                message = TRACK_links.flag(idx);
                TRACK_links.flag(idx) = 2;     % set flag
                %--------------------------------------------------------assign spots of subtrack to TABLE
                T_subtrack.idx(subtrack_co) = idx;
                T_subtrack.spot_A(subtrack_co) = spot_A;
                T_subtrack.spot_B(subtrack_co) = spot_B;
                T_subtrack.flag1(subtrack_co) =  spot_B;   
                T_subtrack.flag2(subtrack_co) = 2;

                subtrack_co = subtrack_co + 1;
                end

        end

        %%   --------------------------------------func_get_all_subtrack_values
        result =  func_get_all_subtrack_values(T_subtrack, TRACK_spots,counter_subtrack);


        fprintf('Track: %d  Subtrack: %d     \n', counter02, counter_subtrack);

        %%   ############################ func_calc_add_values
        % calculates 'step_size', 'track_length','flag' ,'speed_track' , 'dist_total', 'speed_dist', 'angle_2first','num_merges'

        all_values_of_subtrack = func_calc_add_values(result, scales, merges);

        %%   ############################ save
        filename_ = [outdir,'\',...
        'track_',  num2str(counter02, '%04.f'),...
        '_subtrack_',  num2str(counter_subtrack,'%03.f'),'.csv'];
        writetable(all_values_of_subtrack,filename_);

        counter_subtrack = counter_subtrack  +1;

   
end
 warning('on','all')
