function [res] =  func_calc_add_values(T, scales, num_merges)
 xy_scale = scales.xy;
 t_scale = scales.t;


%% new columns
headers = {'step_size', 'track_length','flag' ,'speed_track' , 'dist_total', 'speed_dist', 'angle_2first','num_merges'};
data = nan(height(T),8);
NEW = array2table(data);
NEW.Properties.VariableNames = headers;
T = [T NEW];

%% calculate values for new columns

x_first = T.POSITION_X(1);
y_first = T.POSITION_Y(1);

T.track_length(1) = 0;
color_r = rand(1,3);
for counter_03 = 1:1:(height(T)-1)
        a = counter_03;
        b = a+1;
        first_tracked = T(1,1);

        %% get merges from other table
        T.num_merges(a) = num_merges;
        x1 = T.POSITION_X(a);
        x2 = T.POSITION_X(b);
        y1 = T.POSITION_Y(a);
        y2 = T.POSITION_Y(b);

        % dist_total
        T.dist_total(b) = sqrt((x_first-x2)^2+(y_first-y2)^2);
        % step size
        T.step_size(b) = sqrt((x1-x2)^2+(y1-y2)^2);
        % track_length
        T.track_length(b) = T.track_length(a) + T.step_size(b);
        % speed on track
        T.speed_track(b) =  T.track_length(b) / a* t_scale;
        % speed on distance
        T.speed_dist(b) = T.dist_total(b) / a* t_scale;
        % angle
        angle_rad_f2first = atan2(y2-y_first,x2-x_first);
        T.angle_2first(b) = rad2deg(angle_rad_f2first);
end
res = T;
end