%%%%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
close all
clc;
clearvars;
tStart = tic;
a = datestr(now);
disp(a)
disp('_____________________________________________________________________');