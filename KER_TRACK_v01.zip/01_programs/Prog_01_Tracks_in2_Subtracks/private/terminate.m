% %%%%%%%%%%%%%%%%%%%%%%%%%%%  finishing
disp('_____________________________________________________________________');

tEnd = toc(tStart);
fprintf('running for %d minutes and %f seconds\n',floor(tEnd/60),rem(tEnd,60));
a = datestr(now);
disp(a);
