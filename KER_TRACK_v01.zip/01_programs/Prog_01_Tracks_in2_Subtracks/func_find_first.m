function [res, idx_res] = func_find_first(TRACK_links)
%% find first untracked spot (flag =0), 
%res to return, flag to 1
% index to return

idx = find(TRACK_links.flag ==  0);
idx_res = min(idx);
res = TRACK_links(min(idx),:);
 
        if isempty(idx) == 0    
        res.flag = 1;
        end
end