function [res] =func_get_all_subtrack_values(T_subtrack, TRACK_spots, counter_subtrack)

% add empty columns
spot_type = nan(size(TRACK_spots,1),1);
SUBTRACK = nan(size(TRACK_spots,1),1);
TRACK_spots = addvars(TRACK_spots, spot_type);
TRACK_spots = addvars(TRACK_spots, SUBTRACK);

for co_all = 1 : size(T_subtrack,1)
        idx = find(TRACK_spots.ID==T_subtrack.flag1(co_all));
         T_subtrack_table(co_all,:) =  TRACK_spots(idx , :) ;     
         T_subtrack_table.spot_type(co_all) = T_subtrack.flag2(co_all) ;
         T_subtrack_table.SUBTRACK(co_all) = counter_subtrack ;
end
debug =0;
res = T_subtrack_table;
clearvars T_subtrack_table
end