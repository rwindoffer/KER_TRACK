%% Prog_01_Tracks_in2_Subtracks.m
% further analysis of fiji/trackmate results
% merged tracks are devided into subtracks


% SUBTRACK	ID of subtrack, together with TRACK_ID unique identifier of this subtrack
% step_size	Step size [�m] from previous frame to actual frame
% track_length	Sum of step_sizes [�m] from first frame to actual frame
% flag	not used
% speed_track	track_length/time of actual frame [�m/sec]
% dist_total	Distance [�m] from first frame to actual frame
% speed_dist	Distance / time of actual frame [�m/sec]
% angle_2first	Angle between first position and actual position
% num_merges	number of nodes 


% parfor(parallel execution) possible when looping through tracks, 
% for activation use   'parfor counter02 = 0 : last_track' 
% instead of           'for counter02 = 0 : last_track'





%% %%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE
startup
curr_dir = pwd;
disp('_____________________________________________________________________');
%% data for temporal and xy scaling

 xy_scale = inputdlg('Please enter the pixelsize? [�m] ','Input');
 dt = {inputdlg('Please enter the recording interval? [seconds] ','Input')};
scales.xy = xy_scale;
scales.t =  60/str2double(dt{1,1}); 

 
% xy_scale = 0.0775225; % in �m per pixel                      
% dt = 20; %recording interval in sec
% scales.xy = xy_scale;
% scales.t =  60/dt; 



%% assign directories
cd ..\\
cd ..\\
dir_2_start = pwd;
cd (dir_2_start) % default root dir
dir_name = dir_2_start;

%% load list of files to be processed = load_files 2x
dir_name_load = [dir_name, '\\00_Trackmate\\'];
load_files = dir(fullfile(dir_name_load, '*Spots in tracks statistics.csv'));
nfiles = length(load_files);
load_files_TrackStatistics = dir(fullfile(dir_name_load, '*Links in tracks statistics.csv '));
nfiles_2 = length(load_files_TrackStatistics);

%% assign save directory
%  outdirs{1}=  [dir_name, '\\02_out_trees\\'];
outdir =  [dir_name, '\\02_RESULT_all_subtracks\\'];
cd (curr_dir); % back to working dir



%% ##################################loop through experiments
for counter01 = 1 : nfiles    % 
   
    
    %% load *_Spots in tracks statistics.csv
    work_file = fullfile(dir_name_load, load_files(counter01).name);
    TABLE_SPOTS = readtable(work_file);       
    
    %%  load *_ex001_Links in tracks statistics.csv
    work_file_2 = fullfile(dir_name_load, load_files_TrackStatistics(counter01).name);
    TABLE_LINKS = readtable(work_file_2);
    
    % get last track
    last_track = max(TABLE_SPOTS.TRACK_ID);
    counter03 = 1;

    %% #####################################  loop through Tracks
%    parfor counter02 = 0 : last_track                                               % PARFOR SWITCH
     for counter02 = 0 : last_track 
                if ismember(counter02,TABLE_SPOTS.TRACK_ID) == 1    
                            TRACK_spots = TABLE_SPOTS(TABLE_SPOTS.TRACK_ID == counter02 , :);
                            TRACK_links = TABLE_LINKS(TABLE_LINKS.TRACK_ID == counter02 , :);
                            A_nodes = func_find_nodes(TRACK_links.SPOT_SOURCE_ID, TRACK_links.SPOT_TARGET_ID);    
                            merges = size (A_nodes,1);
                            res = func_get_subtracks(TRACK_spots,TRACK_links, counter02 , merges,scales,  outdir);     
                end % if
     end
end 

%% %%%%%%%%%%%%%%%%%%%%%%%%% TERMINATE
terminate
disp('__________________________________________________');